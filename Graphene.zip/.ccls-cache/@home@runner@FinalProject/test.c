#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <locale.h>
#include <wchar.h>

int main(void){
  setlocale(LC_ALL, "");
  printf("%d\n",'2' - 48);

  return 0;
}